/* =========================================================
   EXATA QUIZ — CONFIGURAÇÃO
   Siga o guia LEIA-ME.html para preencher este arquivo.
   Enquanto ele estiver vazio, o quiz funciona em
   "modo de teste local" (só abas do mesmo navegador).
   ========================================================= */

// 1) Cole aqui os dados do seu projeto Firebase
//    (Configurações do projeto → Seus apps → firebaseConfig)
window.EXATA_FIREBASE = {
  apiKey: "",
  authDomain: "",
  databaseURL: "",
  projectId: "",
  storageBucket: "",
  messagingSenderId: "",
  appId: ""
};

// 2) Seu e-mail de professor (o mesmo cadastrado no Firebase
//    e o mesmo colocado nas regras do banco de dados)
window.EXATA_PROFESSOR_EMAIL = "";
